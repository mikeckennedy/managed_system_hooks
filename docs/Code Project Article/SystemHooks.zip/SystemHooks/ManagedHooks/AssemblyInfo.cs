using System.Reflection;

//
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
//
[assembly: AssemblyTitle("System Hook Class Library")]
[assembly: AssemblyDescription("System Hook Class Library")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Michael Kennedy")]
[assembly: AssemblyProduct("System Hook Class Library")]
[assembly: AssemblyCopyright("Copyright 2004-2005 Michael Kennedy. All rights reserved.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]	

//
// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.2.0.10")]

//
// In order to sign your assembly you must specify a key to use. Refer to the 
// Microsoft .NET Framework documentation for more information on assembly signing.
//
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
